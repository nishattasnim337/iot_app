package com.example.iot_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class navigarion_drawer extends AppCompatActivity {
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;

    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigarion_drawer);
        drawerLayout = findViewById(R.id.drawer);
        navigationView = findViewById(R.id.navigation_view);
        toolbar = findViewById(R.id.toolbar);
        context=this;

        /*
         * Control flow reaching here
         */
        Log.e("DEBUG", "Here2");


        /*-------Migrated portion of the code from #feature.java-------- */
        TextView b_temp=findViewById(R.id.body_temp_name1);
        TextView r_temp=findViewById(R.id.room_temp_name1);
        TextView hum=findViewById(R.id.humidity_name1);


        FirebaseDatabase mdata=FirebaseDatabase.getInstance();
        DatabaseReference mref= mdata.getReference("DHT");
        mref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Map map = (Map) snapshot.getValue();
                b_temp.setText(map.get("bodyTemp").toString());
                hum.setText(map.get("humidity").toString());
                r_temp.setText(map.get("temperature").toString());

                double temp=Double.parseDouble(map.get("bodyTemp").toString());
                double r_temp=Double.parseDouble(map.get("temperature").toString());
                double hum=Double.parseDouble(map.get("humidity").toString());



                Log.e("DEBUG", temp+"");
                // alert for body_temperature
                if(temp<30 || temp>100){
                    new AlertDialog.Builder(context)
                            .setTitle("Temperature Alert")
                            .setMessage("Body Temperature is not normal.")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                }
                            })
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                }

                // alert for room temprature
                if(r_temp<20 || r_temp>40){
                    new AlertDialog.Builder(context)
                            .setTitle("Room Temperature Alert")
                            .setMessage("Room Temperature is not normal.")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                }
                            })
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                }


                // humidity alert message
                // alert for body_temperature
                if(hum<30 || hum>100){
                    new AlertDialog.Builder(context)
                            .setTitle("Humidity Alert")
                            .setMessage("Humidity is not normal.")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                }
                            })
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                }


                //Log.e("DEBUG","Value is: " + snapshot.getValue());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        /*---------------------portion ends here----------------------- */


        //toolbar setup....step 1
        setSupportActionBar(toolbar);

        ActionBarDrawerToggle toogle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.opendrawer, R.string.closedrawer);
        drawerLayout.addDrawerListener((toogle));

        toogle.syncState();
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.history) {
                    showhistory(new historyFragment());


                } else if (id == R.id.profile) {

                    Toast.makeText(navigarion_drawer.this, "profile", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(navigarion_drawer.this, "logout", Toast.LENGTH_SHORT).show();
                }


                drawerLayout.closeDrawer(GravityCompat.START);


                return true;
            }
        });
    }


    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    private void showhistory(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.drawer, fragment);
        fragmentTransaction.commit();

    }
}