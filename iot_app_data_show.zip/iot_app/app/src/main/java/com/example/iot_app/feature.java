package com.example.iot_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class feature extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feature);


        /*
         * Control flow not reaching here
         */
        Log.e("DEBUG","Here4");


        /*-------Migrating this portion of the code to #navigarion_drawer.java-------- */
        TextView b_temp=findViewById(R.id.body_temp_name1);
        TextView r_temp=findViewById(R.id.room_temp_name1);
        TextView hum=findViewById(R.id.humidity_name1);

        FirebaseDatabase mdata=FirebaseDatabase.getInstance();
        DatabaseReference mref= mdata.getReference("DHT");
        mref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Map map = (Map) snapshot.getValue();
                b_temp.setText(map.get("bodyTemp").toString());
                hum.setText(map.get("humidity").toString());
                r_temp.setText(map.get("temperature").toString());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        /*-------portion ends here-------- */


    }
}