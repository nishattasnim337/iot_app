package com.example.iot_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class app_bar_main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_bar_main);
    }
}