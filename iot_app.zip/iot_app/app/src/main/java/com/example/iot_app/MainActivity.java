package com.example.iot_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    private Button button;

    //firebase authentication
    private FirebaseAuth mAuth;
    private EditText emailEditText;
    private  EditText passwordEditText;
    Context context;


// ...
// Initialize Firebase Auth



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.e("DEBUG", "Here1");

        button = (Button) findViewById(R.id.login);
        mAuth = FirebaseAuth.getInstance();
        emailEditText = (EditText) findViewById(R.id.username);
        passwordEditText = (EditText) findViewById(R.id.password);
        Button button = findViewById(R.id.login);


        //firebase authentication.............................
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                loginuser(email,password);
                //mAuth.signInWithEmailAndPassword(email,password);
            }});





        //firebase authentication.............................


    }

    private void loginuser(String email,String password) {

        mAuth.signInWithEmailAndPassword(email,password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // User is successfully logged in
                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                            // Proceed with your app logic or navigation

                            Intent intent = new Intent(MainActivity.this,navigarion_drawer.class);
                            startActivity(intent);

                            // Finish the current activity (optional)
                            finish();
                        } else {
                            // Login failed, display an error message to the user
                            Toast.makeText(getApplicationContext(), "Authentication failed. Please Try again",
                                    Toast.LENGTH_SHORT).show();


                        }
                    }
                });






    }
}