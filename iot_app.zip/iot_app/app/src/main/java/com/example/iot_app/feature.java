package com.example.iot_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class feature extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feature);

        TextView textview3=findViewById(R.id.body_temp_name1);
        TextView number=findViewById(R.id.room_temp_name1);

        FirebaseDatabase mdata=FirebaseDatabase.getInstance();
        DatabaseReference mref= mdata.getReference("DHT");
        mref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Map map = (Map) snapshot.getValue();
                textview3.setText(map.get("humidity").toString());
                number.setText(map.get("temperature").toString());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }


        });
    }
}